# online-exam-wechat-app

#### 项目简介
online-exam-wechat-app 是一个机构在线练习系统的微信小程序。
具有用户管理、在线练习，自动批卷、成绩管理、错题管理、试卷管理、题库管理、试题科目维护等功能。

#### 项目源码

|     |   github  |
|---  |--- |
|  后端源码   |  https://github.com/FreudFan/online-exam-backend   |
|  微信小程序源码   |  https://github.com/FreudFan/online-exam-wechat-app   |
